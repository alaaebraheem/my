document.addEventListener('DOMContentLoaded', () => {
    // Initialize Quill editor
    const quill = new Quill('#editor', {
        theme: 'snow',
        placeholder: 'اكتب روايتك هنا...',
        modules: {
            toolbar: [
                [{ 'header': [1, 2, 3, false] }],
                ['bold', 'italic', 'underline'],
                [{ 'align': [] }],
                [{ 'direction': 'rtl' }],
                ['clean']
            ]
        }
    });

    // Sample featured novels
    const featuredNovels = [
        {
            id: 1,
            title: 'الظل الأسود',
            author: 'أحمد محمود',
            description: 'رواية غامضة عن قصة شاب يكتشف أسرار عائلته',
            language: 'ar',
            status: 'مكتملة'
        },
        {
            id: 2,
            title: 'المدينة المفقودة',
            author: 'سارة العلي',
            description: 'مغامرة مثيرة في عالم خيالي',
            language: 'ar',
            status: 'قيد الترجمة'
        }
    ];

    // Display featured novels
    function displayFeaturedNovels() {
        const featuredContainer = document.getElementById('featuredNovels');
        featuredContainer.innerHTML = featuredNovels.map(novel => `
            <div class="novel-card">
                <div class="novel-content">
                    <h3 class="novel-title">${novel.title}</h3>
                    <p class="novel-author">بقلم: ${novel.author}</p>
                    <p class="text-gray-600 mb-4">${novel.description}</p>
                    <div class="flex justify-between items-center">
                        <span class="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">${novel.language === 'ar' ? 'العربية' : 'الإنجليزية'}</span>
                        <span class="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">${novel.status}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Handle novel form submission
    const novelForm = document.getElementById('novelForm');
    novelForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const novelData = {
            title: document.getElementById('novelTitle').value,
            description: document.getElementById('novelDescription').value,
            language: document.getElementById('novelLanguage').value,
            content: quill.root.innerHTML
        };
        // Here you would typically send the data to a server
        console.log('Novel submitted:', novelData);
        alert('تم حفظ الرواية بنجاح!');
        novelForm.reset();
        quill.setText('');
    });

    // Handle login modal
    const loginBtn = document.getElementById('loginBtn');
    const loginModal = document.getElementById('loginModal');
    const loginForm = document.getElementById('loginForm');

    loginBtn.addEventListener('click', () => {
        loginModal.classList.remove('hidden');
    });

    loginModal.addEventListener('click', (e) => {
        if (e.target === loginModal) {
            loginModal.classList.add('hidden');
        }
    });

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Here you would typically handle login
        alert('تم تسجيل الدخول بنجاح!');
        loginModal.classList.add('hidden');
    });

    // Initialize the page
    displayFeaturedNovels();
});
